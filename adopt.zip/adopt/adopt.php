<?php
include("../config/db.php");

$pet_id = $_GET['pet_id'];

$query = "SELECT * FROM animals WHERE id = $pet_id";
$result = mysqli_query($conn, $query);
$animal = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Adopt a Pet</title>
<link rel="stylesheet" href="../assets/css/style.css?v=2">
</head>
<body>
<?php include("../includes/header.php"); ?>
<div id="pageContent">
  <div class="pet-details">
    <img src="../assets/images/<?php echo $animal['image']; ?>" alt="Pet Image">
    <h2><?php echo $animal['name']; ?></h2>
    <ul>
      <li><strong>Type:</strong> <?php echo $animal['type']; ?></li>
      <li><strong>Age:</strong> <?php echo $animal['age']; ?> year(s)</li>
      <li><strong>Health:</strong> <?php echo $animal['health']; ?></li>
      <li><strong>Friendly:</strong> <?php echo $animal['friendly']; ?></li>
      <li><strong>Urgent:</strong> <?php echo $animal['urgent']; ?></li>
      <li><strong>Size:</strong> <?php echo $animal['size']; ?></li>
      <li><strong>Location:</strong> <?php echo $animal['location']; ?></li>
    </ul>
  </div>
  <div class="adoption-container">
    <h2>Adopt This Pet 🐾</h2>
    <form id="adoptionForm">
      <input type="hidden" name="pet_id" value="<?php echo $animal['id']; ?>">

      <input type="text" name="first_name" placeholder="First name" required>
      <input type="text" name="last_name" placeholder="Last name" required>
      <input type="text" name="phone" placeholder="Phone" required>
      <input type="text" name="address" placeholder="Address" required>

      <textarea name="reason" placeholder="Why adopt?"></textarea>

      <label>
        <input type="checkbox" name="can_take_care" value="1">
        I can take care of the pet
      </label>

      <button type="submit">Confirm Adoption</button>
    </form>
  </div>

</div>
<div id="successCard"></div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$("#adoptionForm").submit(function(e){
  e.preventDefault();

  $.ajax({
    url: "submit_adoption.php",
    method: "POST",
    data: $(this).serialize(),
    dataType: "json",

    success: function(res){

      if(res.status === "success"){
        $("#pageContent").fadeOut(400);
        $("#successCard").html(`
          <div class="pet-card success-card">
            <h3>🐾 Adoption Confirmed</h3>
            <p class="cute">
              Thank you <strong>${res.adopter_name}</strong><br>
              for adopting <strong>${res.pet_name}</strong> ❤️
            </p>
            <p>
              I hope you will give it a warm and loving home.
            </p>
          </div>
        `).hide().fadeIn(600);
        setTimeout(function(){
          window.location.href = "../pets/adopt_pets.php";
        }, 5000);
      }
    }
  });
});
</script>

</body>
</html>

