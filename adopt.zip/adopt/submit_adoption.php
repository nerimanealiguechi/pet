<?php
include("../config/db.php");

$pet_id  = $_POST['pet_id'];
$first   = $_POST['first_name'];
$last    = $_POST['last_name'];
$phone   = $_POST['phone'];
$address = $_POST['address'];
$reason  = $_POST['reason'];
$care    = isset($_POST['can_take_care']) ? 1 : 0;
$sql = "INSERT INTO adoptions 
(pet_id, first_name, last_name, phone, address, reason, can_take_care)
VALUES 
('$pet_id', '$first', '$last', '$phone', '$address', '$reason', $care)";

if (mysqli_query($conn, $sql)) {

    mysqli_query($conn, "
        UPDATE animals 
        SET status = 'Adopted' 
        WHERE id = $pet_id
    ");

    $petQuery = mysqli_query($conn, "SELECT name FROM animals WHERE id = $pet_id");
    $pet = mysqli_fetch_assoc($petQuery);

    echo json_encode([
        "status" => "success",
        "pet_name" => $pet['name'],
        "adopter_name" => $first
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => mysqli_error($conn)
    ]);
}

?>

