<?php
$conn = mysqli_connect("localhost", "root", "", "projectpaw_db");

if (!$conn) {
    die("Database connection failed");
}
?>
